// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>
using namespace std;

// Quick exception class creatsed by Johannes from Stack Overflow
class myException : public std::exception
{
    exception::exception;
};

bool do_even_more_custom_application_logic()
{
    // Throwing a basic exception for a logic app
    throw exception("You're trying to do even more custom logic, but you got an error");
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    
    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    // Added basic exception catch here
    std::cout << "Running Custom Application Logic." << std::endl;
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
        catch (exception e) {
            cout << "There was something wrong with your attempt to do even more logic" << endl;
        }


    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    // if 0 is provided as a value for denominator, throw a runtime error
    if (den == 0) {
        throw runtime_error("Dividing by zero is undefined");
    }
        return (num / den);
    

}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;

    // divide by zero is a runtime_error - catch if div/0 occurs

    try {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (runtime_error& e) {
        cout << "Error: " << e.what() << endl;
    }
  }

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    
    // Looking for exceptions that may or may not be caught and 
    // Displaying an error for those
    try {
        do_division();
        do_custom_application_logic();
        throw myException("Unknown exception");
    }
    catch (...) {
        cout << "Unknown exception caught. Sorry for inconvenience" << endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu